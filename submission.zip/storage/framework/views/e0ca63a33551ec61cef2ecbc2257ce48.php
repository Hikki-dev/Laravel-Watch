<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($name, $params);

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3773094549-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH /Users/hikki/Desktop/Assignments /2nd Year/Semester 2/SSP Assignment/luxwatch-main/luxwatch-app/storage/framework/views/a168b0ebcff266df6b662fc4b6d06e88.blade.php ENDPATH**/ ?>