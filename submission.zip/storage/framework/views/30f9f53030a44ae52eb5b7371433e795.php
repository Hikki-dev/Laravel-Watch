<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/hikki/Desktop/Assignments /2nd Year/Semester 2/SSP Assignment/luxwatch-main/luxwatch-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>